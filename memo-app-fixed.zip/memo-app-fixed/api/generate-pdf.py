from http.server import BaseHTTPRequestHandler
import json
import io
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle,
    Paragraph, Spacer, HRFlowable
)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_RIGHT, TA_CENTER, TA_LEFT


# ── helpers ──────────────────────────────────────────────────────────────────

def inr(amount):
    """Format a number as Indian Rupees."""
    try:
        n = float(amount)
    except (TypeError, ValueError):
        n = 0.0
    return f"\u20b9{n:,.2f}"


def parse_date(iso_string):
    if not iso_string:
        return datetime.now().strftime("%d %b %Y, %I:%M %p")
    try:
        dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
        return dt.strftime("%d %b %Y, %I:%M %p")
    except Exception:
        return datetime.now().strftime("%d %b %Y, %I:%M %p")


# ── colour palette ────────────────────────────────────────────────────────────

C_BLACK   = colors.HexColor("#111827")
C_DARK    = colors.HexColor("#1F2937")
C_MID     = colors.HexColor("#374151")
C_MUTED   = colors.HexColor("#6B7280")
C_LIGHT   = colors.HexColor("#9CA3AF")
C_BORDER  = colors.HexColor("#E5E7EB")
C_ROW_ALT = colors.HexColor("#F9FAFB")
C_HEADER  = colors.HexColor("#F3F4F6")
C_ACCENT  = colors.HexColor("#0EA5E9")


# ── style factory ─────────────────────────────────────────────────────────────

def S(name, **kw):
    defaults = dict(fontName="Helvetica", fontSize=9, textColor=C_BLACK, leading=13)
    defaults.update(kw)
    return ParagraphStyle(name, **defaults)


STYLES = {
    "firm_name":   S("fn",  fontSize=22, fontName="Helvetica-Bold", textColor=C_BLACK, spaceAfter=2),
    "memo_type":   S("mt",  fontSize=13, fontName="Helvetica-Bold", textColor=C_MID, alignment=TA_RIGHT),
    "sub":         S("sub", fontSize=9,  textColor=C_MUTED, spaceAfter=1),
    "label":       S("lbl", fontSize=7.5,fontName="Helvetica-Bold", textColor=C_MUTED, spaceAfter=2),
    "value":       S("val", fontSize=10, textColor=C_BLACK),
    "value_right": S("vr",  fontSize=10, textColor=C_BLACK, alignment=TA_RIGHT),
    "sum_label":   S("sl",  fontSize=9.5,textColor=C_MUTED, alignment=TA_RIGHT),
    "sum_value":   S("sv",  fontSize=9.5,textColor=C_DARK,  alignment=TA_RIGHT),
    "total_label": S("tl",  fontSize=12, fontName="Helvetica-Bold", textColor=C_BLACK, alignment=TA_RIGHT),
    "total_value": S("tv",  fontSize=12, fontName="Helvetica-Bold", textColor=C_BLACK, alignment=TA_RIGHT),
    "footer":      S("ft",  fontSize=8,  fontName="Helvetica-Oblique", textColor=C_LIGHT, alignment=TA_CENTER),
    "th":          S("th",  fontSize=8,  fontName="Helvetica-Bold", textColor=C_MID),
    "th_r":        S("thr", fontSize=8,  fontName="Helvetica-Bold", textColor=C_MID,  alignment=TA_RIGHT),
    "td":          S("td",  fontSize=9,  textColor=C_DARK),
    "td_r":        S("tdr", fontSize=9,  textColor=C_DARK,  alignment=TA_RIGHT),
    "td_c":        S("tdc", fontSize=9,  textColor=C_DARK,  alignment=TA_CENTER),
}


# ── PDF builder ──────────────────────────────────────────────────────────────

def build_pdf(data: dict) -> bytes:
    memo      = data.get("memo") or {}
    items     = data.get("items") or []
    firm      = data.get("firm") or "Firm"
    fd        = data.get("firmData") or {}
    customer  = data.get("customer") or {}
    subtotal  = float(data.get("subtotal") or 0)
    gst_amt   = float(data.get("gstAmt") or 0)
    total     = float(data.get("total") or 0)
    memo_type = data.get("memoType") or "sale"
    gst_on    = gst_amt > 0

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        topMargin=18 * mm,
        bottomMargin=22 * mm,
        leftMargin=22 * mm,
        rightMargin=22 * mm,
        title=f"{firm} – {memo_type.capitalize()} Memo",
    )

    usable_w = A4[0] - 44 * mm   # ≈ 170 mm
    story = []

    # ── 1. Header row: firm name  |  memo type label ─────────────────────────
    firm_name    = fd.get("name") or firm
    address      = fd.get("address") or ""
    phone        = fd.get("phone_number") or ""
    gstin        = fd.get("gst_number") or ""
    footer_note  = fd.get("footer_note") or "Thank you for your business!"

    type_label = "ORDER MEMO" if memo_type == "order" else "SALE MEMO"

    hdr = Table(
        [[Paragraph(firm_name, STYLES["firm_name"]),
          Paragraph(type_label, STYLES["memo_type"])]],
        colWidths=[usable_w * 0.62, usable_w * 0.38],
    )
    hdr.setStyle(TableStyle([
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(hdr)
    story.append(Spacer(1, 3 * mm))

    for line in filter(None, [address, f"Tel: {phone}" if phone else "", f"GSTIN: {gstin}" if gstin else ""]):
        story.append(Paragraph(line, STYLES["sub"]))

    story.append(Spacer(1, 4 * mm))
    story.append(HRFlowable(width="100%", thickness=0.6, color=C_BORDER))
    story.append(Spacer(1, 5 * mm))

    # ── 2. Bill-to / date row ────────────────────────────────────────────────
    cust_name  = customer.get("name")  or "Walk-in Customer"
    cust_phone = customer.get("phone") or "—"
    date_str   = parse_date(memo.get("created_at"))
    memo_id    = memo.get("id") or ""
    memo_ref   = str(memo_id)[:8].upper() if memo_id else "DRAFT"

    meta = Table(
        [
            [Paragraph("Bill To",   STYLES["label"]),  Paragraph(""),
             Paragraph("Date",      STYLES["label"]),  Paragraph("Ref #", STYLES["label"])],
            [Paragraph(cust_name,   STYLES["value"]),  Paragraph(""),
             Paragraph(date_str,    STYLES["value"]),  Paragraph(memo_ref, STYLES["value"])],
            [Paragraph(f"Ph: {cust_phone}", STYLES["sub"]), Paragraph(""),
             Paragraph("",          STYLES["sub"]),    Paragraph("", STYLES["sub"])],
        ],
        colWidths=[usable_w * 0.40, usable_w * 0.04,
                   usable_w * 0.36, usable_w * 0.20],
    )
    meta.setStyle(TableStyle([
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING",   (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 1),
    ]))
    story.append(meta)
    story.append(Spacer(1, 7 * mm))

    # ── 3. Items table ────────────────────────────────────────────────────────
    col_w = [
        usable_w * 0.05,   # #
        usable_w * 0.38,   # Product
        usable_w * 0.12,   # Size
        usable_w * 0.10,   # Qty
        usable_w * 0.17,   # Rate
        usable_w * 0.18,   # Amount
    ]

    rows = [[
        Paragraph("#",       STYLES["th_r"]),
        Paragraph("Product", STYLES["th"]),
        Paragraph("Size",    STYLES["th"]),
        Paragraph("Qty",     STYLES["th_r"]),
        Paragraph("Rate",    STYLES["th_r"]),
        Paragraph("Amount",  STYLES["th_r"]),
    ]]

    for idx, item in enumerate(items, 1):
        name   = item.get("name") or "—"
        size   = item.get("size") or "—"
        qty    = int(item.get("quantity") or 1)
        rate   = float(item.get("unit_price") or 0)
        amount = rate * qty
        rows.append([
            Paragraph(str(idx),   STYLES["td_r"]),
            Paragraph(name,       STYLES["td"]),
            Paragraph(size,       STYLES["td_c"]),
            Paragraph(str(qty),   STYLES["td_r"]),
            Paragraph(inr(rate),  STYLES["td_r"]),
            Paragraph(inr(amount),STYLES["td_r"]),
        ])

    tbl = Table(rows, colWidths=col_w, repeatRows=1)
    row_count = len(rows)

    ts = TableStyle([
        # Header
        ("BACKGROUND",   (0, 0), (-1, 0), C_HEADER),
        ("TOPPADDING",   (0, 0), (-1, 0), 7),
        ("BOTTOMPADDING",(0, 0), (-1, 0), 7),
        ("LINEBELOW",    (0, 0), (-1, 0), 0.6, C_BORDER),
        # Data
        ("TOPPADDING",   (0, 1), (-1, -1), 5),
        ("BOTTOMPADDING",(0, 1), (-1, -1), 5),
        ("LINEBELOW",    (0, 1), (-1, -1), 0.3, C_BORDER),
        ("LEFTPADDING",  (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ])
    # Alternating row shading
    for i in range(1, row_count):
        if i % 2 == 0:
            ts.add("BACKGROUND", (0, i), (-1, i), C_ROW_ALT)
    tbl.setStyle(ts)
    story.append(tbl)
    story.append(Spacer(1, 6 * mm))

    # ── 4. Totals ─────────────────────────────────────────────────────────────
    sum_rows = []
    if not gst_on:
        sum_rows.append(("Subtotal", subtotal))
    else:
        sum_rows += [
            ("Taxable Amount", subtotal),
            ("CGST @ 2.5%",    gst_amt / 2),
            ("SGST @ 2.5%",    gst_amt / 2),
        ]

    totals_data = [
        [Paragraph(lbl, STYLES["sum_label"]),
         Paragraph(inr(val), STYLES["sum_value"])]
        for lbl, val in sum_rows
    ]
    totals_data.append([
        Paragraph("TOTAL",    STYLES["total_label"]),
        Paragraph(inr(total), STYLES["total_value"]),
    ])

    totals_tbl = Table(
        totals_data,
        colWidths=[usable_w * 0.76, usable_w * 0.24],
    )
    totals_tbl.setStyle(TableStyle([
        ("LEFTPADDING",  (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING",   (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 3),
        ("LINEABOVE",    (0, -1), (-1, -1), 0.8, C_BLACK),
        ("TOPPADDING",   (0, -1), (-1, -1), 7),
        ("BOTTOMPADDING",(0, -1), (-1, -1), 7),
    ]))
    story.append(totals_tbl)

    # ── 5. Footer ─────────────────────────────────────────────────────────────
    story.append(Spacer(1, 10 * mm))
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph(footer_note, STYLES["footer"]))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph(
        f"Generated by Memo App · {datetime.now().strftime('%d %b %Y')}",
        STYLES["footer"],
    ))

    doc.build(story)
    return buf.getvalue()


# ── Vercel handler ────────────────────────────────────────────────────────────

class handler(BaseHTTPRequestHandler):

    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            body   = self.rfile.read(length)
            data   = json.loads(body)

            pdf = build_pdf(data)

            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Length", str(len(pdf)))
            self.send_header("Content-Disposition", "inline; filename=memo.pdf")
            self.end_headers()
            self.wfile.write(pdf)

        except Exception as exc:
            msg = json.dumps({"error": str(exc)}).encode()
            self.send_response(500)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)

    def log_message(self, *_):
        pass   # suppress Vercel log noise
